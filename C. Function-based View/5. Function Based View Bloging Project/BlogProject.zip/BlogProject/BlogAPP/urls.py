from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from .import views
from django.conf import settings


urlpatterns = [
  path('',views.indexVIEW, name='index'),
  path('display/',views.display, name='display'),
  path('details/<int:id>',views.detailsView, name='details'),  
  path('like/<int:id>',views.likeView, name='like'),
  

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

