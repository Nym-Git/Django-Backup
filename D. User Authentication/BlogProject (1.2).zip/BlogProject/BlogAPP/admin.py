from django.contrib import admin
from .models import Instruction,Comment,Google_Add,Category,User_Information
# Register your models here.

admin.site.register(Instruction)
admin.site.register(Comment)
admin.site.register(Google_Add)
admin.site.register(Category)
admin.site.register(User_Information)